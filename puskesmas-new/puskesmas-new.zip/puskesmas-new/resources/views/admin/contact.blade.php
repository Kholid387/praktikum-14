<x-layout>
    <x-slot name='page_name'>Halaman Contact</x-slot>
</x-layout>