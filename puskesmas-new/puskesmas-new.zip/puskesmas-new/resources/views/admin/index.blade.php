<x-layout>
    <x-slot name="page_name">Halaman Home</x-slot>
</x-layout>