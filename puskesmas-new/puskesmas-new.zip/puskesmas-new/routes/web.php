<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\PasienController;
use App\Http\Controllers\KelurahanController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/selam', function () {
    return "selamat belajar fahri";
});

Route::get('/Beranda', function (){
    return "halaman beranda";
});

Route::get('/profile', function() {
    return"Halaman Profile";
});


//Praktikum Laravel 22
Route::get('/dashboard', [AdminController::class, 'index' ]);
Route::get('/contact', [ContactController::class, 'index' ]);

//Praktikum laravel 3
Route::get('/dashboard/pasien', [PasienController::class, 'index' ]);
Route::get('/dashboard/kelurahan', [KelurahanController::class, 'index' ]);
